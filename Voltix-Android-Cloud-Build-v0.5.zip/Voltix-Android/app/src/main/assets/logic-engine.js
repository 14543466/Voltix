/* Educational symbolic validator. It checks component metadata and presence rules only;
   it does not inspect terminal wiring or certify electrical safety. */
(function (root) {
  'use strict';
  const fa = (message) => ({ fa: message });
  const en = (message) => ({ en: message });
  function parseVoltage(value) {
    const s = String(value || '').toUpperCase().replace(/\s/g, '').replace(',', '.');
    const m = s.match(/(\d+(?:\.\d+)?)(V)(AC|DC)?/);
    return m ? { volts: Number(m[1]), kind: m[3] || null } : null;
  }
  function parseRange(value) {
    const s = String(value || '').replace(',', '.');
    const m = s.match(/(\d+(?:\.\d+)?)\s*[–-]\s*(\d+(?:\.\d+)?)/);
    return m ? [Number(m[1]), Number(m[2])] : null;
  }
  function parsePositive(value) {
    const m = String(value || '').replace(',', '.').match(/\d+(?:\.\d+)?/);
    return m ? Number(m[0]) : null;
  }
  function validateCircuit(items, settings) {
    items = Array.isArray(items) ? items : [];
    settings = settings || {};
    const errors = [], warnings = [], notes = [];
    const types = items.map(x => x && x.type).filter(Boolean);
    const has = type => types.includes(type);
    const count = type => types.filter(x => x === type).length;
    const issue = (level, code, faText, enText) => ({ level, code, fa: faText, en: enText });

    if (!items.length) errors.push(issue('error','EMPTY','هیچ جزئی به مدل اضافه نشده است.','The model contains no components.'));
    if (items.length && !['coil','lamp','motor'].some(has)) errors.push(issue('error','NO_OUTPUT','هیچ خروجی نمادینی (بوبین، چراغ یا بار) تعریف نشده است.','No symbolic output (coil, lamp, or load) is defined.'));
    if (has('start') && !has('stop')) warnings.push(issue('warning','NO_STOP','شستی توقف در فهرست اجزا وجود ندارد.','No stop pushbutton is represented in the component list.'));
    if (has('motor') && !has('overload')) warnings.push(issue('warning','NO_OVERLOAD','برای بار نمادین، رله اضافه‌بار در مدل دیده نمی‌شود.','No overload relay is represented for the symbolic load.'));
    if (has('motor') && !has('fuse')) warnings.push(issue('warning','NO_PROTECTION','جزء حفاظت مدار در مدل دیده نمی‌شود.','No circuit-protection component is represented.'));
    if (has('start') && has('coil') && !has('aux')) warnings.push(issue('warning','NO_HOLDING_CONTACT','کنتاکت کمکی برای نمایش منطق خودنگهدار در فهرست اجزا وجود ندارد.','No auxiliary contact is represented for a seal-in logic example.'));
    if (count('coil') > 1 && !has('interlock')) warnings.push(issue('warning','NO_INTERLOCK','چند بوبین وجود دارد اما جزء اینترلاک منطقی تعریف نشده است.','Multiple coils are present without a represented logic interlock.'));

    const control = parseVoltage(settings.controlVoltage || '');
    if (!control) warnings.push(issue('warning','CONTROL_VOLTAGE_UNKNOWN','ولتاژ کنترلی قابل‌خواندن نیست؛ سازگاری ولتاژ بررسی نشد.','Control voltage could not be parsed; voltage compatibility was not checked.'));
    items.forEach((item, index) => {
      const label = item.name || item.type || `#${index + 1}`;
      if (item.type === 'coil') {
        const v = parseVoltage(item.value);
        if (!v) warnings.push(issue('warning','COIL_VOLTAGE_UNKNOWN',`ولتاژ بوبین «${label}» مشخص یا قابل‌خواندن نیست.`,`The coil voltage for “${label}” is missing or unreadable.`));
        else if (control && (v.volts !== control.volts || (v.kind && control.kind && v.kind !== control.kind))) {
          errors.push(issue('error','COIL_VOLTAGE_MISMATCH',`ولتاژ بوبین «${label}» با ولتاژ کنترلی انتخاب‌شده یکسان نیست (فقط مقایسه داده‌ها).`,`The coil voltage for “${label}” differs from the selected control voltage (metadata comparison only).`));
        }
      }
      if (item.type === 'timer') {
        const n = parsePositive(item.value);
        if (!n || n <= 0) errors.push(issue('error','TIMER_VALUE_INVALID',`زمان رله زمانی «${label}» باید مقدار مثبت و قابل‌خواندن داشته باشد.`,`Timer “${label}” must have a readable positive time value.`));
      }
      if (item.type === 'overload') {
        const range = parseRange(item.value);
        if (!range || range[0] <= 0 || range[1] <= range[0]) warnings.push(issue('warning','OVERLOAD_RANGE_UNKNOWN',`محدوده رله اضافه‌بار «${label}» قابل‌خواندن نیست.`,`The overload range for “${label}” is unreadable.`));
      }
      if (item.type === 'fuse') {
        const n = parsePositive(item.value);
        if (!n || n <= 0) warnings.push(issue('warning','PROTECTION_VALUE_UNKNOWN',`مقدار حفاظتی «${label}» مشخص نیست.`,`The displayed protection value for “${label}” is missing or unreadable.`));
      }
    });
    const loadCurrent = Number(settings.loadCurrent);
    if (!Number.isFinite(loadCurrent) || loadCurrent <= 0) errors.push(issue('error','LOAD_CURRENT_INVALID','جریان نمایشی بار باید عددی بزرگ‌تر از صفر باشد.','The displayed load current must be a number greater than zero.'));

    notes.push(issue('info','LIMITATION','این نسخه فقط وجود اجزا و سازگاری برخی مشخصات متنی را بررسی می‌کند؛ ترتیب اجزا، سیم‌کشی ترمینال‌ها و عملکرد واقعی مدار را اثبات نمی‌کند.','This version checks component presence and selected metadata only; it does not prove terminal wiring, circuit behavior, or real-world safety.'));
    if (!errors.length && !warnings.length) notes.unshift(issue('success','BASIC_PASS','بررسی‌های پایه بدون خطا یا هشدار انجام شد؛ این نتیجه تأیید مدار واقعی نیست.','Basic checks found no errors or warnings; this is not approval of a real circuit.'));
    return { errors, warnings, notes, passed: errors.length === 0 && warnings.length === 0 };
  }
  root.ICDLogic = { validateCircuit, parseVoltage, parseRange };
})(typeof window !== 'undefined' ? window : globalThis);
