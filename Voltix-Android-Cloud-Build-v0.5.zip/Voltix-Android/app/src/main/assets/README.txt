Industrial Control Designer — Prototype v0.2

Bilingual Persian/English mobile web app, installable on Android from a secure browser origin.

Current features:
- Manual component selection, ordering, editing and local persistence
- Educational automatic logic templates
- New standalone symbolic validation engine (logic-engine.js)
- Checks for missing symbolic outputs, stop/overload/protection representation, auxiliary-contact/interlock representation, invalid timer values, unreadable component values and coil/control-voltage metadata mismatches
- Print / Save as PDF
- Offline cache via service worker

Android install:
1. Host this folder on HTTPS (or use a local development server).
2. Open index.html in Chrome on Android.
3. Choose browser menu > Install app / Add to Home screen.

Important limitations:
This is an educational symbolic prototype, not a full electrical CAD editor. Components are currently represented as an ordered list, not terminal-to-terminal connected symbols. The validator cannot verify actual wiring, protection coordination, standards compliance, or electrical safety. It must never be used to build, wire, energize, or approve a real industrial installation. Real designs require qualified engineering review.
